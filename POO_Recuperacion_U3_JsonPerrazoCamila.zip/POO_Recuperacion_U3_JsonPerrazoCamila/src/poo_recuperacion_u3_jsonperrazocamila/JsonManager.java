
package poo_recuperacion_u3_jsonperrazocamila;
import java.io.File;
import java.io.IOException;
import java.util.List;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonManager {
    private static final String FILE_PATH = "inventario.json";
    
    public static void guardarEnJSON(List<Producto> productos){
        ObjectMapper objectMapper = new ObjectMapper();
        try{
            objectMapper.writeValue(new File(FILE_PATH),productos);
            System.out.println("Productos guardados en "+FILE_PATH);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public static List<Producto> cargarDesdeJSON(){
        ObjectMapper objectMapper = new ObjectMapper();
        try{
            return objectMapper.readValue(new File(FILE_PATH),objectMapper.getTypeFactory().constructCollectionType(List.class, Producto.class));           
        }catch(IOException e){
            e.printStackTrace();
            return null;
        }
    }
}
