
package poo_recuperacion_u3_jsonperrazocamila;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class POO_Recuperacion_U3_JsonPerrazoCamila {

    public static void main(String[] args) {
      List<Producto>productoList = new ArrayList<>();
      Scanner scanner = new Scanner(System.in);
      int opc;
      do{
          mostrarMenu();
          opc = scanner.nextInt();
          scanner.nextLine();
          switch(opc){
              case 1:
                  productoList.add(crearProducto(scanner));
                  break;
                  
              case 2:
                  mostrarProducto(productoList);
                  break;
                  
              case 3:
                  JsonManager.guardarEnJSON(productoList);
                  break;
                  
              case 4:
                   productoList = JsonManager.cargarDesdeJSON();
                   if(productoList != null){
                       System.out.println("Datos cargado desde JSON");
                   }
                  break;
                  
              case 5:
                  System.out.println("Saliendo del programa...");
                  break;
              default:
                  System.out.println("Ha ingresado una opcion incorrecta, por favor intente de nuevo");
                  
          }
      }while(opc !=5);
      scanner.close();
    }
    
    private static void mostrarMenu(){
        System.out.println("=======GESTION DE INVENTARIO DE PRODUCTOS=======");
        System.out.println("================MENU DE OPCIONES================");
        System.out.println("1. Ingresar producto.");
        System.out.println("2. Mostrar producto.");
        System.out.println("3. Guardar producto en Json.");
        System.out.println("4. Cargar producto desde Json.");
        System.out.println("5. Salir");
    }
    private static Producto crearProducto(Scanner scanner){
        System.out.println("Ingrese el codigo:");
        int codigo = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Ingrese el nombre");
        String nombre = scanner.nextLine();
        System.out.println("Ingrese el precio");
        double precio = scanner.nextDouble();
        System.out.println("Ingrese la cantidad");
        int cantidad = scanner.nextInt();
        return new Producto(codigo, nombre, precio, cantidad);
    }
    
    private static void mostrarProducto(List<Producto> productoList){
        System.out.println("Productos");
        for(Producto producto : productoList){
            System.out.println(producto);
        }
    }
}
